#include <iostream>
#include <string>
using namespace std;
class Vehicle {
public:
    string name;
    string model;
    int year;
};
class FlyingObject {
public:
    double max_height;
    double fuelcapacity;
};
class FlyingVehicle : public Vehicle, public FlyingObject {
public:
    void initialize() {
        Vehicle::name = "Vehicle";
        Vehicle::model = "Model of Vehicle";
        Vehicle::year = 2023;
        FlyingObject::max_height = 36000.0;
        FlyingObject::fuelcapacity = 6800;
    }
    void display() 
	{
		cout << "---------Vehicle Properties------------" << endl;
        cout << "Vehicle Name : " << Vehicle::name << endl;
        cout << "Vehicle Model : " << Vehicle::model << endl;
        cout << "Vehicle Year : " << Vehicle::year << endl;
        cout << "----------Flying Object Properties---------" << endl;
        cout << "Maximum Height : " << FlyingObject::max_height << " feet" << endl;
        cout << "Fuel Capacity : " << FlyingObject::fuelcapacity << " meters" << endl;
    }
};
int main() {
    FlyingVehicle flyingVehicle;
    flyingVehicle.initialize();
    flyingVehicle.display();
    return 0;
}

