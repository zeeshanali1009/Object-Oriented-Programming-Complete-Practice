#include <iostream>
#include <string>
using namespace std;
class Person
{
public:
    string Name;
    int Age;
    float Height;
};
class Employee
{
public:
    string Name;
    double Salary;
    double cnic;
};
class EmployeeRecord : public Person, public Employee
{
public:
    void Initializing()
    {
        Person::Name = "Person";
        Person::Age = 30;
        Person::Height = 5.8;
        Employee::Name = "Employee";
        Employee::Salary = 200000.0;
        Employee::cnic = 123456;
    }
    void Displaying()
    {
        cout << "----------Person Related Details-----------" << endl;
        cout << "Name: " << Person::Name << endl;
        cout << "Age: " << Person::Age << endl;
        cout << "Height: " << Person::Height << endl;
        cout << "\n----------Employee Related Details----------" << endl;
        cout << "Name: " << Employee::Name << endl;
        cout << "Salary: " << Employee::Salary << endl;
        cout << "CNIC: " << Employee::cnic << endl;
    }
};
int main()
{
    EmployeeRecord record;
    record.Initializing();
    record.Displaying();

    return 0;
}

